using System;
using System.Collections;
using System.Collections.Generic;
using Core.System;
using TMPro;
using UnityEngine;

namespace Game {
	[RequireComponent(typeof(TMP_Text))]
	public class TMP_LocalizedText : MonoBehaviour {
		private TMP_Text _text;

		public string key = "1";

		private void Start() {
			_text = GetComponent<TMP_Text>();
			
			_text.text = LanguageManager.Instance.Get(key);
			LanguageManager.Instance.Subscribe(Refresh);
		}

		private void OnDestroy() {
			LanguageManager.Instance.Unsubscribe(Refresh);
		}

		public void Refresh() {
			_text.text = LanguageManager.Instance.Get(key);
		}
	}
}
