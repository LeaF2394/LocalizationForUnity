using System;
using System.Collections;
using System.Collections.Generic;
using Core.Anim;
using Core.Extensions;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Game
{
    public class Button_Element : Button {
        public ColorBlock transitionColors;
        
        public event Action OnClick;
        public event Action OnHover;

        private TMP_Text  _text;
        private Coroutine _animCoroutine;

        protected override void Awake() {
            base.Awake();
            _text = GetComponentInChildren<TMP_Text>();
        }

        private void Update() {
            _text.color = image.color.Invert();
        }

        public override void OnPointerEnter(PointerEventData eventData) {
            base.OnPointerEnter(eventData);
            OnHover?.Invoke();
            
            if(_animCoroutine != null) StopCoroutine(_animCoroutine);
            StartCoroutine(image.AnimColor(image.color, transitionColors.highlightedColor, transitionColors.fadeDuration));
        }

        public override void OnPointerExit(PointerEventData eventData) {
            base.OnPointerExit(eventData);
            
            if(_animCoroutine != null) StopCoroutine(_animCoroutine);
            StartCoroutine(image.AnimColor(image.color, transitionColors.normalColor, transitionColors.fadeDuration));
        }

        public override void OnPointerDown(PointerEventData eventData) {
            base.OnPointerDown(eventData);
            
            if(_animCoroutine != null) StopCoroutine(_animCoroutine);
            StartCoroutine(image.AnimColor(image.color, transitionColors.pressedColor, transitionColors.fadeDuration));
        }

        public override void OnPointerUp(PointerEventData eventData) {
            base.OnPointerUp(eventData);
            OnClick?.Invoke();
            
            if(_animCoroutine != null) StopCoroutine(_animCoroutine);
            StartCoroutine(image.AnimColor(image.color, transitionColors.highlightedColor, transitionColors.fadeDuration));
        }
    }
}
