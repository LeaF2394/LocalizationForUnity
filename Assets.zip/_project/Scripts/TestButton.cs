﻿using System;
using System.Collections.Generic;
using Core.System;
using UnityEngine;
using UnityEngine.UI;

namespace Game {
	[RequireComponent(typeof(Button))]
	public class TestButton : MonoBehaviour {
		private Button _button;

		[SerializeField] private List<string> langList = new();
		private                  int          index = 0;

		private void Awake() {
			_button = GetComponent<Button>();
		}

		private void Start() {
			_button.onClick.AddListener(OnClick);
		}

		private void OnClick() {
			LanguageManager.Instance.SetLanguage(langList[index]);
			
			if (index >= langList.Count - 1) {
				index = 0;
				return;
			}

			index++;
		}

		private void OnDestroy() {
			_button.onClick.RemoveAllListeners();
		}
	}
}
