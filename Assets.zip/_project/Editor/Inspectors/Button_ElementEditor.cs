﻿using System;
using UnityEditor;

namespace Game.Editor.Inspectors {
	[CustomEditor(typeof(Button_Element))]
	public class Button_ElementEditor : UnityEditor.Editor {
		private Button_Element btn;
		private SerializedProperty  transitionColors;

		private void OnEnable() {
			btn = (Button_Element)target;
			transitionColors = serializedObject.FindProperty("transitionColors");
		}

		public override void OnInspectorGUI() {
			base.OnInspectorGUI();
			serializedObject.Update();
		}
	}
}
