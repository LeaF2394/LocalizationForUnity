using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace Game.Editor {
	[InitializeOnLoad]
	public static class CompilationCountdown {
		static CompilationCountdown() {
			CompilationPipeline.compilationStarted +=
					o => {
						StartCompilation();
					};

			CompilationPipeline.compilationFinished +=
					o => {
						EndCompilation();
					};
		}

		private static double _startTime;

		static void StartCompilation() {
			_startTime = EditorApplication.timeSinceStartup;
		}

		static void EndCompilation() {
			double end = EditorApplication.timeSinceStartup;
			double dur = end - _startTime;

			Debug.Log($"编译耗时 {dur:F3} s");
		}
	}
}
