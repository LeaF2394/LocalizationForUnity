﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Core.Extensions {
	public static class DictionaryExtension {
		public static Dictionary<TKey, TValue> Merge<TKey, TValue>(this Dictionary<TKey, TValue> first, Dictionary<TKey, TValue> second) {
			if (first  == null) throw new ArgumentNullException();
			if (second == null) throw new ArgumentNullException();

			foreach (var pair in second) {
				if (first.ContainsKey(pair.Key)) first[pair.Key] = pair.Value;
				else first.Add(pair.Key, pair.Value);
			}

			return first;
		}
	}

	public static class ColorExtension {
		public static Color Invert(this Color color, bool invertAlpha = false) {
			Color c = new Color(1 - color.r, 1 - color.g, 1 - color.b, invertAlpha? 1 - color.a : color.a);
			return c;
		}
	}
}
