﻿using System.Collections.Generic;
using System.IO;
using Core.Utils;
using Newtonsoft.Json;
using UnityEngine;

namespace Core {
	public class GameConfig : MonoSingleton<GameConfig> {
		public Config settings { get; private set; }
		
		public void Init() {
			DontDestroyOnLoad(this);
		}

		public void Set(Config _settings) {
			settings = _settings;
			string cfgPath = Path.Combine(Application.persistentDataPath, "settings.json");
			
			if (File.Exists(cfgPath)) {
				var attr = File.GetAttributes(cfgPath);
				if (attr != FileAttributes.Normal) {
					File.SetAttributes(cfgPath, FileAttributes.Normal);
				}
			}

			string json = JsonConvert.SerializeObject(settings);
			File.WriteAllText(cfgPath, json);
		}
	}
}
