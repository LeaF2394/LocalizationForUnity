﻿using System.IO;
using Core.System;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Core {
	public static class Bootstrap {
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		public static void Boot() {
			// 1. 初始化
			SceneManager.LoadScene(0);
			
			GameConfig.Instance.Init();
			LanguageManager.Instance.Init();
			
			// 2. 加载配置
			Config settings;
			string cfgPath = Path.Combine(Application.persistentDataPath, "settings.json");

			bool isFirstRun = !File.Exists(cfgPath);

			if (isFirstRun) {
				settings = new() {
										 language = "undef"
								 };
				string json = JsonConvert.SerializeObject(settings);
				File.WriteAllText(cfgPath, json);
			}
			else {
				string json = File.ReadAllText(cfgPath);
				settings = JsonConvert.DeserializeObject<Config>(json);
			}
			
			// 3. 最终加载
			Load(settings);
			GameConfig.Instance.Set(settings);
			
			// 4. 加载完毕进入开始菜单场景
			SceneManager.LoadScene(1);
		}

		static void Load(Config settings) {
			if (settings.language.ToLower().Trim().Equals("undef")) {
				// 显示设置语言UI界面
				// 这里就不演示了
				settings.language = "en_us";
			}
			
			// 加载语言
			string language = settings.language;
			LanguageManager.Instance.Load(language);
		}
	}
}
