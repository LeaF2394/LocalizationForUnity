﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Core.Anim {
	public static class AnimationTween {
		public static IEnumerator AnimColor(this Image image, Color from, Color to, float duration) {
			float elapsedTime = 0;
			image.color = from;

			while (elapsedTime < duration) {
				elapsedTime += Time.deltaTime;
				float t = Mathf.Clamp01(elapsedTime / duration);
				
				image.color = Color.Lerp(from, to, t);
				yield return null;
			}
			
			image.color = to;
			yield return new WaitForEndOfFrame();
		}
	}
}
