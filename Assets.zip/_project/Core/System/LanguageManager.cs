﻿using System;
using System.Collections.Generic;
using System.IO;
using Core.Extensions;
using Core.Utils;
using Newtonsoft.Json;
using UnityEngine;

namespace Core.System {
	public class LanguageManager : MonoSingleton<LanguageManager> {
		private          string                     _language;
		private readonly Dictionary<string, string> _languageDictionary = new();
		private event Action OnLanguageChanged; 

		public void Init() {
			DontDestroyOnLoad(this);
		}

		private void OnDestroy() {
			_languageDictionary.Clear();
			OnLanguageChanged = null;
		}

		public void Load(string language) {
			_language = language;
			_languageDictionary.Clear();

			string path = Path.Combine(Application.streamingAssetsPath, "lang", $"{_language}.json");

			try {
				if (File.Exists(path)) {
					var attr = File.GetAttributes(path);
					if (attr != FileAttributes.Normal) {
						File.SetAttributes(path, FileAttributes.Normal);
					}
					
					string json = File.ReadAllText(path);
					var    dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
					_languageDictionary.Merge(dict);
					
					Debug.Log(json);	// 加载成功打印一下，方便调试
				}
				else {
					Debug.LogError("File not found: " + path);
					throw new FileNotFoundException();
				}
			}
			catch (Exception ex) {
				Debug.LogException(ex);
			}
		}

		public void SetLanguage(string language) {
			_language = language;
			Load(language);
			Config cfg = GameConfig.Instance.settings;
			cfg.language = _language;
			
			GameConfig.Instance.Set(cfg);
			OnLanguageChanged?.Invoke();
		}
		
		public string Get(string key) => _languageDictionary.GetValueOrDefault(key, key);

		public void Subscribe(Action onLanguageChanged) {
			OnLanguageChanged += onLanguageChanged;
		}

		public void Unsubscribe(Action onLanguageChanged) {
			OnLanguageChanged -= onLanguageChanged;
		}
	}
}
