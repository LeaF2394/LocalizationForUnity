﻿using UnityEngine;

namespace Core.Utils {
	public abstract class MonoSingleton<TSingleton> : MonoBehaviour where TSingleton : MonoSingleton<TSingleton> {
		private static TSingleton _instance;
		public static TSingleton Instance {
			get {
				if (_instance == null) {
					_instance = FindAnyObjectByType<TSingleton>();

					if (_instance == null) {
						GameObject obj = new GameObject(typeof(TSingleton).Name);
						_instance = obj.AddComponent<TSingleton>();
					}
				}
				
				return _instance;
			}
		}

		protected virtual void Awake() {
			if (_instance != null &&
				_instance != this) {
				Destroy(gameObject);
				return;
			}
			
			_instance = this as TSingleton;
		}
	}
}
